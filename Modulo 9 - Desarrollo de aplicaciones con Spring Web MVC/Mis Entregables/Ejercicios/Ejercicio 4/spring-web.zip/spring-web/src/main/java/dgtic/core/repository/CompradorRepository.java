package dgtic.core.repository;

import dgtic.core.model.entities.CompradorEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompradorRepository extends JpaRepository<CompradorEntity,Integer> {

}
