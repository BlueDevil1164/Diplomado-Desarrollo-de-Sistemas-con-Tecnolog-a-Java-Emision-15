package dgtic.core.repository;

import dgtic.core.model.entities.CapturaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CapturaRepository extends JpaRepository<CapturaEntity,Integer> {
}
