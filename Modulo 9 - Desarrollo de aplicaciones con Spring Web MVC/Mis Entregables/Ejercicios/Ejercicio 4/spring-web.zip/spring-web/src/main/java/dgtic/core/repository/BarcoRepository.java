package dgtic.core.repository;

import dgtic.core.model.entities.BarcoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BarcoRepository extends JpaRepository<BarcoEntity,Integer> {
}
