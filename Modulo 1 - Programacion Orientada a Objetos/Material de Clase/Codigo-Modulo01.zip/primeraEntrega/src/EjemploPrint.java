// Carlos Eligio Ortiz
// Ejemplos de print y de println

public class EjemploPrint {
    public static void main (String[] args){
        System.out.print ("Universidad Nacional ");  // Ejemplo de print
        System.out.println ("Autónoma de México");
        System.out.println ("Diplomado de Java");
    }
}
