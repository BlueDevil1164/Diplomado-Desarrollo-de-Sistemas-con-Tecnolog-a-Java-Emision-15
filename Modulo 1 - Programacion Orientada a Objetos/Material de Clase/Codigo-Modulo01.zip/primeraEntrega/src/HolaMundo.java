// Esta es mi primer clase
public class HolaMundo {
    public static void main (String[] args) {
        System.out.println ("¡¡¡ Hola mundo !!!");
    }  // Fin del método
} // Fin de la clase
