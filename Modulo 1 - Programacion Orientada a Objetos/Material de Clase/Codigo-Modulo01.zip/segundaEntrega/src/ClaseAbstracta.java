public abstract class ClaseAbstracta {
    public String nombre;
    public int numero;

    public int suma (int otroNumero){
        return this.numero + otroNumero;
    }

    public abstract int resta (int otroNumero);
    // public abstract int duplica ();

}
