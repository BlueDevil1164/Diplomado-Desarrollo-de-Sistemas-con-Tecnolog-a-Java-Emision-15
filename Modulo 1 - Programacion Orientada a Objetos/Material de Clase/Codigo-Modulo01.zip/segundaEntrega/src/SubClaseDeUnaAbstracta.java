public class SubClaseDeUnaAbstracta extends ClaseAbstracta{
    public boolean logico;

    public int resta (int valor){
        return this.numero-valor;
    }

}
