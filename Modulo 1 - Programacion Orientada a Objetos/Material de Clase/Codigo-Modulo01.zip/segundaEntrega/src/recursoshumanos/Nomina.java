package recursoshumanos;

public class Nomina {
    public void calcula(){
        Empleado objeto1 = new Empleado();
        objeto1.nombre = "Luz";
        /// objeto1.genero = 'F'; // Es privado
        objeto1.sueldo = 111; // Es protegidos
    }
}
