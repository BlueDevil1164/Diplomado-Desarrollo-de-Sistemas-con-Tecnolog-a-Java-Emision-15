package recursoshumanos;

public class Empleado {
    public String nombre;
    private char genero;
    protected double sueldo;

}
