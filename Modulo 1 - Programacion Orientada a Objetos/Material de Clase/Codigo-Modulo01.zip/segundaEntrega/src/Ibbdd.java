public interface Ibbdd {
    public abstract boolean altaBBDD();
    public abstract boolean bajaBBDD();
}
