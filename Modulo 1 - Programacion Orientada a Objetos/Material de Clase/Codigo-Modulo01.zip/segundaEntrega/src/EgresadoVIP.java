public class EgresadoVIP{
}
