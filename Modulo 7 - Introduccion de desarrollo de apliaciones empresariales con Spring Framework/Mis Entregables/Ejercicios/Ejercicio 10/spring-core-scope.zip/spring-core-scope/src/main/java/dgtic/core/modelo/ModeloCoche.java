package dgtic.core.modelo;

public interface ModeloCoche {
    public void crear();
}
