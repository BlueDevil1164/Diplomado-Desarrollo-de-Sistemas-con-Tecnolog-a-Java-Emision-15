package dgtic.core.modelo;

public interface Actividades {
    public void realiza();
}
