package dgtic.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCorePojodaotestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCorePojodaotestApplication.class, args);
	}

}
