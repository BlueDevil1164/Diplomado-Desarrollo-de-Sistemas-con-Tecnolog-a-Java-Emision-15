package dgtic.core.modelo;

public interface Actividades {
    void realiza();
}
