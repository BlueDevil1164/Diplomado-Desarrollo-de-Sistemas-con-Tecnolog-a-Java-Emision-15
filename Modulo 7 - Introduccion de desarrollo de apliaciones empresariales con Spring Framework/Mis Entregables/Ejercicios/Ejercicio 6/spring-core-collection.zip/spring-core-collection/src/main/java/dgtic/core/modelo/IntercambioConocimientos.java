package dgtic.core.modelo;

public class IntercambioConocimientos implements Actividades{
    @Override
    public void realiza() {
        System.out.println("Conocimientos");
    }
}
