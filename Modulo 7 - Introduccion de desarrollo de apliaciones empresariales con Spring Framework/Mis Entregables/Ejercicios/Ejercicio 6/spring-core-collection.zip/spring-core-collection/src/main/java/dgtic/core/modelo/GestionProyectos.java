package dgtic.core.modelo;

public class GestionProyectos implements Actividades{
    @Override
    public void realiza() {
        System.out.println("Gestion Proyectos");
    }
}
