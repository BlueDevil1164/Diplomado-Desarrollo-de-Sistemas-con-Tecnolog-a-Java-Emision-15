package dgtic.core.modelo;

public class TodoTerreno implements  ModeloCoche{
    @Override
    public void crear() {
        System.out.println("Tipo de carro todoterreno");
    }
}
