package dgtic.modelo;

public class ExplicarClases implements Responsabilidades{

    @Override
    public void realizar() {
        System.out.println("Explicar clases");
    }

    public void actividades(){

    }
}
