package dgtic.core.servicio;

public interface ReporteEmpleadoServicio {
    public void reporteDiario();
}
