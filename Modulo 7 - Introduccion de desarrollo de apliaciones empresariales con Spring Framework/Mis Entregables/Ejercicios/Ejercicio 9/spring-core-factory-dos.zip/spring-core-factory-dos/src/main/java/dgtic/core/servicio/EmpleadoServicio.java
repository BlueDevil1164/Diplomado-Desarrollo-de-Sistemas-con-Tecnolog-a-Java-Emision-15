package dgtic.core.servicio;

public interface EmpleadoServicio {
    public void servicioEmpleado();
}
