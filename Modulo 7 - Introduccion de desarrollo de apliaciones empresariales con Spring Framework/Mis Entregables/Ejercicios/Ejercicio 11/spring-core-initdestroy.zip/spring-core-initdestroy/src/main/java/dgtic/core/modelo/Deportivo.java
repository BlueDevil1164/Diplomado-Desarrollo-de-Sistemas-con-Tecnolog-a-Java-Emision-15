package dgtic.core.modelo;

public class Deportivo implements ModeloCoche{
    @Override
    public void crear() {
        System.out.println("Es un deportivo");
    }
}
