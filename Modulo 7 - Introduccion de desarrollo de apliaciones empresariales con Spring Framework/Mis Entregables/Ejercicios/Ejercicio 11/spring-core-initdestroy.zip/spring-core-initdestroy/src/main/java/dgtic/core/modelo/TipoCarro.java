package dgtic.core.modelo;

public enum TipoCarro {
    DEPORTIVO, FAMILIAR, TODOTERRENO
}
