package dgtic.Inicio;

import dgtic.modelo.Profesor;

public class MetodoDos {
    public static void main(String[] args){
        Profesor profesor = new Profesor();
        profesor.getResponsabilidades();
    }
}
