package dgtic.modelo;

public class Responsabilidades {

    public Responsabilidades(){

    }

    public void explicarClases(){

    }

    public void reportes(){

    }

    public void explicarClase(){
        System.out.println("explica clase");
    }
}
