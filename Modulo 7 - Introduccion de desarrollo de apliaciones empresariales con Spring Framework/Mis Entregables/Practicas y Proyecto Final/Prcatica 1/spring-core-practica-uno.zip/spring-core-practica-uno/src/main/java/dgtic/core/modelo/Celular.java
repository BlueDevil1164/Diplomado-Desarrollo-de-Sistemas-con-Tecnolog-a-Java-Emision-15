package dgtic.core.modelo;

public class Celular implements Productos{
    @Override
    public void registrar() {
        System.out.println("Ha comprado un Celular");

    }
}
