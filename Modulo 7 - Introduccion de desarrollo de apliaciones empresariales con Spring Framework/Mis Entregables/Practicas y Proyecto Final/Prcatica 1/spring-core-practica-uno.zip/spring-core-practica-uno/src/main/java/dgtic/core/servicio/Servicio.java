package dgtic.core.servicio;

public class Servicio {

}
