package dgtic.core.modelo;

public enum TipoElectronico {

    LAPTOP,CELULAR,TABLET

}
