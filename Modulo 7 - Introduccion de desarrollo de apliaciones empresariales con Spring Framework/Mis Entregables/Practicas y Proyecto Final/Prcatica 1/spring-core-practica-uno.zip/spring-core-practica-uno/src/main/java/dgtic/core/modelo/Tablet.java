package dgtic.core.modelo;

public class Tablet implements  Productos{
    @Override
    public void registrar() {
        System.out.println("Ha comprado una Tablet");
    }
}
