package dgtic.core.modelo;

public class Laptop implements Productos{
    @Override
    public void registrar() {
        System.out.println("Ha comprado una Laptop");
    }
}
