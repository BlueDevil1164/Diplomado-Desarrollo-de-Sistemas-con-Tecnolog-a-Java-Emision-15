package dgtic.core.modelo;

public interface Productos {
    public void registrar();
}
