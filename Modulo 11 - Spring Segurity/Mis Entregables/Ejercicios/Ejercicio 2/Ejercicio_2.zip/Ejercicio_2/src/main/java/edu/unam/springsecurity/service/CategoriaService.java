package edu.unam.springsecurity.service;

import org.springframework.stereotype.Service;

@Service
public class CategoriaService {
	public String getText() {
		return "Categoria";
	}
}
