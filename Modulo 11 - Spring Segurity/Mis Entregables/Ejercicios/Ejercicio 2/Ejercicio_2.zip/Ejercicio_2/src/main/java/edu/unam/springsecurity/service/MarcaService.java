package edu.unam.springsecurity.service;

import org.springframework.stereotype.Service;

@Service
public class MarcaService {
	public String getText() {
		return "Marca";
	}
}
