package edu.unam.springsecurity.service;

import org.springframework.stereotype.Service;

@Service
public class CompradorService {
	public String getText() {
		return "Comprador";
	}
}
