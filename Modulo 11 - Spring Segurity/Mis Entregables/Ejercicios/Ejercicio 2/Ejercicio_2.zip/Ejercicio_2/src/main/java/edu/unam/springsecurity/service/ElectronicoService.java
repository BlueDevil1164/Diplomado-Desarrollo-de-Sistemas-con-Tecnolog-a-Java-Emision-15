package edu.unam.springsecurity.service;

import org.springframework.stereotype.Service;

@Service
public class ElectronicoService {
	public String getText() {
		return "Electronico";
	}
}
