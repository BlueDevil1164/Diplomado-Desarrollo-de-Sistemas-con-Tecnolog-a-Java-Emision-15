package edu.unam.springsecurity.service;

import org.springframework.stereotype.Service;

@Service
public class VendedorService {
	public String getText() {
		return "Vendedor";
	}
}
