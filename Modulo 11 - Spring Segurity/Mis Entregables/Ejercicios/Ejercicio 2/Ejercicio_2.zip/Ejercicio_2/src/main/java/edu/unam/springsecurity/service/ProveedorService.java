package edu.unam.springsecurity.service;

import org.springframework.stereotype.Service;

@Service
public class ProveedorService {
	public String getText() {
		return "Proveedor";
	}
}
