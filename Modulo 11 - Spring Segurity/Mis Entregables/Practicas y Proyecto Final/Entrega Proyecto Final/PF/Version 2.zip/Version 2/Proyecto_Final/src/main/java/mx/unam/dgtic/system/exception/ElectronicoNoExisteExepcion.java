package mx.unam.dgtic.system.exception;


public class ElectronicoNoExisteExepcion extends Exception{

    public ElectronicoNoExisteExepcion(String message){
        super(message);
    }
}
