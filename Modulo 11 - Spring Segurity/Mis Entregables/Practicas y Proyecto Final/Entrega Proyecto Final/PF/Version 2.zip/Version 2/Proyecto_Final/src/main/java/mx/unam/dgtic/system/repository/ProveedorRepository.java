package mx.unam.dgtic.system.repository;

import mx.unam.dgtic.system.model.Proveedor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProveedorRepository extends JpaRepository<Proveedor, Integer> {


}
