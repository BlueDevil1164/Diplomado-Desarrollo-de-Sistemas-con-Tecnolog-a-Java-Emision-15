package mx.unam.dgtic.system.exception;


public class VendedorNoExisteExepcion extends Exception{

    public VendedorNoExisteExepcion(String message){
        super(message);
    }
}
