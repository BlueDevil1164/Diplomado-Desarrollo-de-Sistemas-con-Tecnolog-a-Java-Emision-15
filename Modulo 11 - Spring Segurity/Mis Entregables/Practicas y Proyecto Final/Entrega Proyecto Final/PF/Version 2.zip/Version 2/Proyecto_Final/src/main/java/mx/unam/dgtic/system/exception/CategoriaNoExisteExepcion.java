package mx.unam.dgtic.system.exception;


public class CategoriaNoExisteExepcion extends Exception{

    public CategoriaNoExisteExepcion(String message){
        super(message);
    }
}
