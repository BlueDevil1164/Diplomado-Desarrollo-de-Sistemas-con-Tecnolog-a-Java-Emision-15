package mx.unam.dgtic.system.exception;


public class MarcaNoExisteExepcion extends Exception{

    public MarcaNoExisteExepcion(String message){
        super(message);
    }
}
