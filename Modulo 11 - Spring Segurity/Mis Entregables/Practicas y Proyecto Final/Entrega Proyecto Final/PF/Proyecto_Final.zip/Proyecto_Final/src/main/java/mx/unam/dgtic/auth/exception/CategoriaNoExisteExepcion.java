package mx.unam.dgtic.auth.exception;


public class CategoriaNoExisteExepcion extends Exception{

    public CategoriaNoExisteExepcion(String message){
        super(message);
    }
}
