package mx.unam.dgtic.auth.repository;

import mx.unam.dgtic.auth.model.Proveedor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProveedorRepository extends JpaRepository<Proveedor, Integer> {


}
