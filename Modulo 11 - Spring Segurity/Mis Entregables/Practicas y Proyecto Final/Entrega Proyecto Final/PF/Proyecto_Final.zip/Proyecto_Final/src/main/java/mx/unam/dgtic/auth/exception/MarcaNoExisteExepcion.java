package mx.unam.dgtic.auth.exception;


public class MarcaNoExisteExepcion extends Exception{

    public MarcaNoExisteExepcion(String message){
        super(message);
    }
}
