package mx.unam.dgtic.auth.exception;


public class ElectronicoNoExisteExepcion extends Exception{

    public ElectronicoNoExisteExepcion(String message){
        super(message);
    }
}
