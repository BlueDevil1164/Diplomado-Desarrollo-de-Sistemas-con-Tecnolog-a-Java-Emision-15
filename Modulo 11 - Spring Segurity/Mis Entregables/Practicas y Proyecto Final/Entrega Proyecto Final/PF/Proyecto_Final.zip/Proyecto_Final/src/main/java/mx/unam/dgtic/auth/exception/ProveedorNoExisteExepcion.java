package mx.unam.dgtic.auth.exception;


public class ProveedorNoExisteExepcion extends Exception{

    public ProveedorNoExisteExepcion(String message){
        super(message);
    }
}
