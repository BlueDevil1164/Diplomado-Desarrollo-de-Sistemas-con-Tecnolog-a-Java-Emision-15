package mx.unam.dgtic.auth.exception;


public class CompradorNoExisteExepcion extends Exception{

    public CompradorNoExisteExepcion(String message){
        super(message);
    }
}
