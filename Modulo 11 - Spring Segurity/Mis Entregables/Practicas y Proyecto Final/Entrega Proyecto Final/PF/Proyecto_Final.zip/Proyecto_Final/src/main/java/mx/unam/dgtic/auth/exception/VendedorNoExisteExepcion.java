package mx.unam.dgtic.auth.exception;


public class VendedorNoExisteExepcion extends Exception{

    public VendedorNoExisteExepcion(String message){
        super(message);
    }
}
