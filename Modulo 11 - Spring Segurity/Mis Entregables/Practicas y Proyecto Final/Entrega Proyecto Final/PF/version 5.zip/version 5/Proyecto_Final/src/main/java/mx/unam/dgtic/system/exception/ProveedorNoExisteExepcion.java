package mx.unam.dgtic.system.exception;


public class ProveedorNoExisteExepcion extends Exception{

    public ProveedorNoExisteExepcion(String message){
        super(message);
    }
}
