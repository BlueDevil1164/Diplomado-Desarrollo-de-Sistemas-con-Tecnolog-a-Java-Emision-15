package com.dgtic.dstj15.isp.impresora;

public class Documento {
    private String contenido;
}
