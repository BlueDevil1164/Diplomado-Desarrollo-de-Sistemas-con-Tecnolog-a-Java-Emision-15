package com.dgtic.dstj15.srp.calculadora;

public class App {
    public static void main(String[] args) {
        Calculadora calculadora = new Calculadora();
        System.out.println(calculadora.tangente(12));
    }
}
