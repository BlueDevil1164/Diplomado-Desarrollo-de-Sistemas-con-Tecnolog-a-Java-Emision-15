package com.dgtic.dstj15.lsp.procesadorpagos;

public enum TipoCripto {
    BC,
    ETH,
    NEAR,
    TRON,
    BAT,
    DAI,
    USDC

}
