package com.dgtic.dstj15.isp.gestiongimnasio;

import com.dgtic.dstj15.isp.gestiongimnasio.view.GymGestionView;

public class app {
    public static void main(String[] args) {
        GymGestionView view = new GymGestionView();
        view.iniciar();
    }
}
