package com.dgtic.dstj15.ocp.pintor;

public class Figura {
}

class Cuadrado extends Figura {
}

class Circulo extends Figura {
}