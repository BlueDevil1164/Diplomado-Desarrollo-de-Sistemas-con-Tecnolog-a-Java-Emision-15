package com.dgtic.dstj15.dip.gestionpedidos.model;

public record Orden(
    int id,
    String producto,
    double cantidad
    
) {
    
}
