public class Main {
    public static void main(String[] args) {
        var calc=new Calculator();
        System.out.println(calc.toString());
    }
}
