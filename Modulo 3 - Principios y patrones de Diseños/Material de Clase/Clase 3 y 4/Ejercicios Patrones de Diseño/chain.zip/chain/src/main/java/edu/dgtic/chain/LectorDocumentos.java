package edu.dgtic.chain;

public interface LectorDocumentos {
	String contenido(Documento documento);
}
