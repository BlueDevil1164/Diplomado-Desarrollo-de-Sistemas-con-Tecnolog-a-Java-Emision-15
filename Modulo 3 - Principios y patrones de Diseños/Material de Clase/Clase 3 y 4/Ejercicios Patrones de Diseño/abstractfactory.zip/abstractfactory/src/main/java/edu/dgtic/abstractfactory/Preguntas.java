package edu.dgtic.abstractfactory;

public interface Preguntas {
	String preguntaHora();
	String preguntaTiempo();
}
