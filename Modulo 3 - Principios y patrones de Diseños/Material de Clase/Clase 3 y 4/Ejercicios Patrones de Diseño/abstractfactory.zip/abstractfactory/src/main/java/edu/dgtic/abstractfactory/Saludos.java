package edu.dgtic.abstractfactory;

public interface Saludos {
	String buenosDias();
	String buenasTardes();
}
