package com.unam.dgtic.observer;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface HealthObserver {
    // void notify(String message);
    void update(String message);
}
