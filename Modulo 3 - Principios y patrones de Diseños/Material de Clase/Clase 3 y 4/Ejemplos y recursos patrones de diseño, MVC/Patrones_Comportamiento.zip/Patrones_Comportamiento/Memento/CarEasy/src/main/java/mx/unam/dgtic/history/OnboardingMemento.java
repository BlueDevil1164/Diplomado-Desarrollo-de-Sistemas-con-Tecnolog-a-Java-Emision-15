package mx.unam.dgtic.history;

import mx.unam.dgtic.state.OnboardingState;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface OnboardingMemento {
    OnboardingState getState();
}
