package mx.unam.dgtic.service;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface OnfidoService {
    void validateIndentity(String name, String email);

}
