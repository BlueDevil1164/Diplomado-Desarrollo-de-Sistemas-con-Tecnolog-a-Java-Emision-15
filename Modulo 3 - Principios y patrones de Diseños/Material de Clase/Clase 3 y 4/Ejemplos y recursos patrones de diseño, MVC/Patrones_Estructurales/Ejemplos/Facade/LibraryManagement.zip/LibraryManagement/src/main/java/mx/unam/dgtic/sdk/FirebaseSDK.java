package mx.unam.dgtic.sdk;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class FirebaseSDK {
   public static void createUser(String name, String email){
        // createUSer...
    }
}
