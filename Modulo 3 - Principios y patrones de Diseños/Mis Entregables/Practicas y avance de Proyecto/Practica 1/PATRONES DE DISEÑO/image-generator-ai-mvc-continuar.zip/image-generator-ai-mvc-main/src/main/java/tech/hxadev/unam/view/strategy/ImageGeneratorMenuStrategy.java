package tech.hxadev.unam.view.strategy;

public class ImageGeneratorMenuStrategy implements MenuStrategy{
    @Override
    public void execute() {
        /***
         * Implementar logica
         * **/
    }
}
