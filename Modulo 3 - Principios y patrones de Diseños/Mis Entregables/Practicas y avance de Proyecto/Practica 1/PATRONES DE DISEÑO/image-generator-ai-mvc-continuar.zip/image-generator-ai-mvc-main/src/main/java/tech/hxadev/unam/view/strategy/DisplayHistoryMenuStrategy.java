package tech.hxadev.unam.view.strategy;

public class DisplayHistoryMenuStrategy implements MenuStrategy{
    @Override
    public void execute() {
        /***
         * Implementar logica
         * **/
    }
}
