package tech.hxadev.unam.view.strategy;

public class DisplayImagesByPrompStrategy implements MenuStrategy{
    @Override
    public void execute() {
    /***
     * Implementar logica
     * **/

    }
}
