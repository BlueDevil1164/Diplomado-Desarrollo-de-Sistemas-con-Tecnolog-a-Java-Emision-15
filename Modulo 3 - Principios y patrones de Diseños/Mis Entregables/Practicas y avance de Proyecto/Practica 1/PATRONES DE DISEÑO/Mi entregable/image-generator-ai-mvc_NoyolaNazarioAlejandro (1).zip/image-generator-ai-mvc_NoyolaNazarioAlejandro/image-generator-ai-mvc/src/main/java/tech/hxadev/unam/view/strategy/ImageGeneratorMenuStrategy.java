package tech.hxadev.unam.view.strategy;

import tech.hxadev.unam.controller.ImageGeneratorController;
import tech.hxadev.unam.entities.GenerationInfo;
import tech.hxadev.unam.entities.ImageDAO;

import java.util.Scanner;

import static java.lang.System.out;

public class ImageGeneratorMenuStrategy implements  MenuStrategy{

    private final ImageGeneratorController controller;

    public ImageGeneratorMenuStrategy(ImageGeneratorController controller) {
        this.controller = controller;
    }

    @Override
    public void execute() {
        controller.generateImage(GenerationInfo.builder().prompt(this.inputPrompt()).build());

    }
    private String inputPrompt(){
        bannerPrompt();
        return new Scanner(System.in).nextLine();
    }

    private void bannerPrompt() {

        out.println(">> Que imagen quieres generar? ");
        out.print(">> ");
    }
}
