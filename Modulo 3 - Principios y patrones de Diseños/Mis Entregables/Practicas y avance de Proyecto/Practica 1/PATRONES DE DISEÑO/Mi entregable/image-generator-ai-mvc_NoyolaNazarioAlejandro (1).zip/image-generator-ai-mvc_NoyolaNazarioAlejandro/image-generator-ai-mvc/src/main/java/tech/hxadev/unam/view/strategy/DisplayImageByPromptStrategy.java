package tech.hxadev.unam.view.strategy;

import tech.hxadev.unam.controller.ImageGeneratorController;
import tech.hxadev.unam.entities.ImageDAO;
import tech.hxadev.unam.view.ImageGeneratorView;

import java.util.Scanner;

import static java.lang.System.out;

public class DisplayImageByPromptStrategy implements MenuStrategy{

    private final ImageGeneratorController controller;

    public DisplayImageByPromptStrategy(ImageGeneratorController controller) {
        this.controller = controller;
    }

    @Override
    public void execute() {
        bannerPromptExist();
        String prompt = new Scanner(System.in).nextLine();
        ImageDAO image = this.controller
                .getImageByPromp(prompt);
        if (image == null){
            throw new RuntimeException("¡¡¡¡¡ No se encontro la imagen con el prompt !!!!!!! :  " + prompt);
        }
        System.out.println(
                "Image Name:" + image.getName() +
                        " Image URL:" + image.getUrl() +
                        " Image Creation Date:" + image.getCreated()
        );
    }

    private void bannerPromptExist() {
        out.println(">> Ingresa el prompt de la imagen que quieres obtener ");
        out.print(">> ");
    }
}
