package tech.hxadev.unam.controller.factory;

import tech.hxadev.unam.client.AIGeneratorClient;

public interface ClientFactory {
    AIGeneratorClient generateClient();
}
