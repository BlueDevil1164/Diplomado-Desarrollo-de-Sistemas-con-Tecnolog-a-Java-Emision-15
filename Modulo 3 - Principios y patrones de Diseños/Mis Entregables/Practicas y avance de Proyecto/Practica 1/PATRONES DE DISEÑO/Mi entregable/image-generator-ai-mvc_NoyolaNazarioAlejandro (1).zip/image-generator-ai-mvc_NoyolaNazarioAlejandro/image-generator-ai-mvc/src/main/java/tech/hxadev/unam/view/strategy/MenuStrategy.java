package tech.hxadev.unam.view.strategy;

import tech.hxadev.unam.view.ImageGeneratorView;

public interface MenuStrategy {

    void execute();

}
