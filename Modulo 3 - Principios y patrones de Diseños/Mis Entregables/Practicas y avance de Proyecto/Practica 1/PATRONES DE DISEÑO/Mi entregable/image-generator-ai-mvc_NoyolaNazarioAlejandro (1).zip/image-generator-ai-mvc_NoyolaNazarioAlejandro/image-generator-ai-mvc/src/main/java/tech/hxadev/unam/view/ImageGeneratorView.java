package tech.hxadev.unam.view;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import static java.lang.System.in;
import static java.lang.System.out;

import tech.hxadev.unam.controller.ImageGeneratorController;
import tech.hxadev.unam.view.strategy.*;

/**
 * @author
 * @since 1.0
 */
public class ImageGeneratorView  {
    private final ImageGeneratorController controller;
    private final Map<Integer, MenuStrategy> strategies = new HashMap<>();

    public ImageGeneratorView(ImageGeneratorController controller) {
        this.controller = controller;
        this.initializeStrategies();
    }

    private void initializeStrategies(){
        strategies.put(0, new SalidaStrategy());
        strategies.put(1, new ImageGeneratorMenuStrategy(controller));
        strategies.put(2, new DisplayHistoryMenuStrategy(controller));
        strategies.put(3, new DisplayImageByPromptStrategy(controller));

    }

    public void run() {
        try (Scanner scanner = new Scanner(in)) {
            int opcion;
            do {
                this.showBanner();
                opcion = scanner.nextInt();
                MenuStrategy strategy = strategies.get(opcion);
                if (strategy != null) {
                    strategy.execute();
                } else {
                    out.println("Opción inválida");
                }
            } while (opcion != 0);
        } catch (Exception ex) {
            out.println("Error: " + ex.getMessage());
        }
    }

    private void showBanner() {
        out.println("\n+++ Generador de imágenes utilizando AI +++");
        out.println("\n+++ Selecciona la opción que deseas utilizar +++");
        out.println("\n+++ 1) Generar imagen - 2) Mostrar historial - 3) Obtener Imagen por prompt - 0) Salir +++");
    }
}
