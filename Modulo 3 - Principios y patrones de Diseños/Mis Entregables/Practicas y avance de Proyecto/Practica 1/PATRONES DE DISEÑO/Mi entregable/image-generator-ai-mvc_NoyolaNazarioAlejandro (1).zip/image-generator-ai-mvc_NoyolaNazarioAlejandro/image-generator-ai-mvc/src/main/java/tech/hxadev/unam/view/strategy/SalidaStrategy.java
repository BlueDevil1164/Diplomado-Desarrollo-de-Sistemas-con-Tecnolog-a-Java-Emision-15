package tech.hxadev.unam.view.strategy;

public class SalidaStrategy implements MenuStrategy {
    @Override
    public void execute(){
        System.out.println("Nos vemos!");
    }
}
