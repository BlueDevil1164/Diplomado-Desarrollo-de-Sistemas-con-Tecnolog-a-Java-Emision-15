package tech.hxadev.unam.view.strategy;

import tech.hxadev.unam.controller.ImageGeneratorController;
import tech.hxadev.unam.entities.ImageDAO;
import tech.hxadev.unam.view.ImageGeneratorView;

import java.util.Scanner;

public class DisplayHistoryMenuStrategy implements MenuStrategy {

    private final ImageGeneratorController controller;

    public DisplayHistoryMenuStrategy(ImageGeneratorController controller) {
        this.controller = controller;
    }
    @Override
    public void execute() {
        this.controller.getImages().stream()
                .forEach(image -> {
                    System.out.println(
                            "Image Name:" + image.getName() +
                                " Image URL:" + image.getUrl() +
                                " Image Creation Date:" + image.getCreated());
                });
    }

}
