/***
 ** Unidad 3 - Principios y Patrones de Diseño
 ** @Producto: {{Interfaz EstadoPedido}}
 ** @author: {{Noyola Nazario Alejandro}}
 ** @Fecha: {{20 de Junio 2024}}
 ***/

//Decalaramos metodos void que seran necesarios para la clase Pedido
public interface EstadoPedido {
    void procesar();
    void cancelarPedido();
}

