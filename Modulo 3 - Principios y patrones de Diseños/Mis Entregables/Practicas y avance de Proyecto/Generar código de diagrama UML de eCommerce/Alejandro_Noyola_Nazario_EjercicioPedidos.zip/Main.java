//package com.hxadev.unam.producto.ejercicio;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 ** @Producto: {{Nombre del Producto}}
 ** @author: {{Noyola Nazario Alejandro}}
 ** @Fecha: {{20 de Junio 2014}}
 ***/
public class Main {
    public static void main(String[] args) {
    // Escribe el codigo inicial aqui.
    
        
    }
}