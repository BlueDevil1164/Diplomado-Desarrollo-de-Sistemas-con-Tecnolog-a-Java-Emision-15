package edu.dgtic.lsp;

// Interfaz Shape

public interface Shape {
    double computeArea();
}


