package edu.dgtic.srp;

public class UserPersistenceService {
}
