package unam.diplomado.pixup.usuario.repository;

import unam.diplomado.pixup.usuario.domain.Domicilio;

public interface DomicilioRepository {

    Domicilio save(Domicilio domicilio);

}
