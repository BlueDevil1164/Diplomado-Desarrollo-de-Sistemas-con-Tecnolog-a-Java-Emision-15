package unam.diplomado.pixup;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.annotation.FacesConfig;

@FacesConfig
@ApplicationScoped
public class FacesActivator {

}
