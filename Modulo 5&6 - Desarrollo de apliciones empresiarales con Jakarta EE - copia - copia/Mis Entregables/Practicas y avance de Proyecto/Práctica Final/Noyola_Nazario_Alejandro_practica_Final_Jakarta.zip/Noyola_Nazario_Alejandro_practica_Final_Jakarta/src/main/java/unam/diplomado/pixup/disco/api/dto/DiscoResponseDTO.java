package unam.diplomado.pixup.disco.api.dto;

public class DiscoResponseDTO {

    private Integer id;
    private String titulo;


}
