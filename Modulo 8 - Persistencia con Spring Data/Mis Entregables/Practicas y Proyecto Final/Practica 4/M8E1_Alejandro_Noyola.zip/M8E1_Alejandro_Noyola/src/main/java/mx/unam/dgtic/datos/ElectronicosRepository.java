package mx.unam.dgtic.datos;

import org.springframework.data.repository.CrudRepository;

public interface ElectronicosRepository extends CrudRepository<Electronicos, Integer> {
}
