package mx.unam.dgtic.datos.paginado;

public interface ConteoPorCampo {
    String getCampo();

    Long getConteo();
}
