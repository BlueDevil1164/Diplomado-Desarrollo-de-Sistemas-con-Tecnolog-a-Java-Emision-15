package mx.unam.dgtic.datos.electronicos;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ProveedorRepository extends CrudRepository<Proveedor, Integer> {


}
