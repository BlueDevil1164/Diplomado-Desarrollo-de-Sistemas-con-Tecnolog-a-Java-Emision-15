package mx.unam.dgtic.datos.paginado;

import mx.unam.dgtic.datos.paginado.Comprador;
import org.springframework.data.repository.CrudRepository;

public interface CompradorRepository extends CrudRepository<Comprador, Integer> {
}
