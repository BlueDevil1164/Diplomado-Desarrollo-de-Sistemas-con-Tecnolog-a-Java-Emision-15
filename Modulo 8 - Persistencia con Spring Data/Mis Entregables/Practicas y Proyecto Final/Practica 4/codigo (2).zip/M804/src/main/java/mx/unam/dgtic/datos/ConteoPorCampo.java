package mx.unam.dgtic.datos;

public interface ConteoPorCampo {
    String getCampo();

    Long getConteo();
}
