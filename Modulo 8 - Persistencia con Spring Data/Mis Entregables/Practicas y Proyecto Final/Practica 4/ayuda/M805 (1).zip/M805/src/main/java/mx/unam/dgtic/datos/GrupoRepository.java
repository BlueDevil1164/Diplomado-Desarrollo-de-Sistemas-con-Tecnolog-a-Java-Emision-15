package mx.unam.dgtic.datos;

import org.springframework.data.repository.CrudRepository;

public interface GrupoRepository extends CrudRepository<Grupo, Integer> {

}
