package mx.unam.dgtic.datos;

import org.springframework.data.repository.CrudRepository;

public interface VendedorRepository extends CrudRepository<Vendedor, Integer> {
}
