package mx.unam.dgtic.datos;

import org.springframework.data.repository.CrudRepository;

public interface CompradorRepository extends CrudRepository<Comprador, Integer> {
}
