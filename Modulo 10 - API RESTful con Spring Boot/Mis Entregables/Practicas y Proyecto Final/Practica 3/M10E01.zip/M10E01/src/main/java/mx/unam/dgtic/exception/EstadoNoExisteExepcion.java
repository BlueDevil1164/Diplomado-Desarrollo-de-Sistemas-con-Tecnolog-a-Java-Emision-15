package mx.unam.dgtic.exception;

public class EstadoNoExisteExepcion extends Exception{

    public EstadoNoExisteExepcion(String message){
        super(message);
    }
}
