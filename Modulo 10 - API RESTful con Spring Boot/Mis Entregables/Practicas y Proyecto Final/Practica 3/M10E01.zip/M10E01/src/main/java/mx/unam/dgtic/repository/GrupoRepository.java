package mx.unam.dgtic.repository;

import mx.unam.dgtic.model.Grupo;
import org.springframework.data.repository.CrudRepository;

public interface GrupoRepository extends CrudRepository<Grupo, Integer> {
}
