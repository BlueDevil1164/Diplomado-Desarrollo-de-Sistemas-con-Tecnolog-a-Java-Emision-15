package mx.unam.dgtic.core.m10_00;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M1000Application {

	public static void main(String[] args) {
		SpringApplication.run(M1000Application.class, args);
	}

}
