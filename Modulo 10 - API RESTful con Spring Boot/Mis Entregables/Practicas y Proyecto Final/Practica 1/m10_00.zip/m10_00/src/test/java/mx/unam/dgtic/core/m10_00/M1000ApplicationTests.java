package mx.unam.dgtic.core.m10_00;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M1000ApplicationTests {

	@Test
	void contextLoads() {
	}

}
